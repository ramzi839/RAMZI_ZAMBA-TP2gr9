/** 
 * @file VersionService.hpp
 * @author Philippe-Henri Gosselin
 * @date 9 décembre 2015
 * @copyright CNRS
 */

#ifndef __VersionService_hpp__
#define __VersionService_hpp__

#include "AbstractService.hpp"

#include "VersionService.h"

#endif

